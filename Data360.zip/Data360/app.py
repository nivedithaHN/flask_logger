from flask import Flask, request
from logger.custom_log_methods import logCustomError, logUserRequestResp

app = Flask(__name__)

@app.route('/sample', methods=['GET'])
def sample():
    try:
        logUserRequestResp({"user_query": "J&J sales for year 2021", "db_query": "select * from sample", "response": [{"sales_2022": 8768576}]})
        return {"status": "Success"}
    except Exception as e:
        logCustomError({"exception": str(e), "method": "sample()", "route": "/sample"})
        return {"status": "Failed"}



if __name__ == '__main__':
	app.run(host="127.0.0.1", port=8087)