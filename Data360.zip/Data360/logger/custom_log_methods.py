from datetime import datetime
import pytz

from logger import log

log.file_path("logs/data360_logs_{time:MM_YY!UTC}.log") # log file path
log.setMode(['error','info','custom'])

fmt = '%Y-%m-%d %H:%M:%S %Z%z'

class FunctionLog():
    error_msg : str
    exception_msg: str
    function: str
    parent_route: str
    add_info: str

def logCustomError(error_log: FunctionLog):
    timestamp = datetime.now(tz=pytz.utc).strftime(fmt)
    error_log['timestamp'] = timestamp
    log.error(error_log)

def logUserRequestResp(user_log):
    timestamp = datetime.now(tz=pytz.utc).strftime(fmt)
    user_log['timestamp'] = timestamp
    log.custom_info(user_log)



